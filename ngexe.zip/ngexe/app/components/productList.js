//引入
import React, { Component } from 'react';
import {Text,View,FlatList} from 'react-native';
//创建一个类
export default class DemoProductListComponent
extends Component{
    constructor(){
        super()
        this.state={list:[]}
    }
    componentDidMount(){
         var url="http://meilele.applinzi.com/index/threeproduct"
         fetch(url)
         .then((response)=>{
             return response.json()
         })
         .then((result)=>{
             console.log(result)
             this.setState({list:result})
         })
    }
    showItem=(info)=>{
        return <Text key={info.index}>{info.item}</Text>
    }
   render(){
       return <FlatList data={this.state} renderItem={this.showItem}>
              <Text>{this.state.item}</Text>
       </FlatList>
   }
}