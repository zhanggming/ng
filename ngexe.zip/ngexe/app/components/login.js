//引入
import React, { Component } from 'react';
import {Text,Image,View,TextInput,Button} from 'react-native';
//创建一个类
export default class DemoLoginComponent
extends Component{
    //获取输入框的值
      //发送网络请求
      //验证登录
      //跳转
     // this.props.navigation.navigate('main')
     constructor(){
         super()
         this.state={uname:'',upwd:''}
     }
    //保存用户名
    handleChangeNameText=(msg)=>{
     //写操作
     this.setState({uname:msg})
    }
    //保存密码
    handleChangePwdText=(msg)=>{
     //写操作
     this.setState({upwd:msg})
    }
    handlePress=()=>{
       // console.log(this.state)
        var url="http://meilele.applinzi.com/user/login";
        var options={
            method:"POST",
            headers:{
                "Content-Type":"application/x-www-form-urlencoded"
            },
            body:"uname="+this.state.uname+"&upwd="+this.state.upwd
        }
        fetch(url,options).then((response)=>{
            return response.json()
        }).then((result)=>{
            //console.log(result)
            if(result.code==1){
                this.props.navigation.navigate("main")
            }else{
             //清空输入框
              this.setState({uname:'',upwd:''})
            }
        })
    }
   render(){
       return <View>
          <Text style={{fontSize:40,color:'red',alignSelf:'center'}}>登录</Text>
          <Image style={{width:300,height:200,borderRadius:75,alignSelf:'center'} }source={{uri:"http://mllvue.applinzi.com/img/index/banner/banner2.jpg"}}></Image>
           <TextInput placeholder="请输入用户名" onChangeText={this.handleChangeNameText} value={this.state.uname}></TextInput>
           <TextInput placeholder="请输入密码" onChangeText={this.handleChangePwdText} secureTextEntry={true}></TextInput>
           <Button onPress={this.handlePress} title="登录"></Button>
           </View>
   }
}