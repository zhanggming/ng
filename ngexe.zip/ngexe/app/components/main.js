//引入
import React, { Component } from 'react';
import {Text,View,Image,StyleSheet,TouchableOpacity,ScrollView} from 'react-native';
//创建一个类
export default class DemoMainComponent
extends Component{
    jump=()=>{
        this.props.navigation.navigate("productList")
    }
   render(){
       return <View style={styles.container}>
           {/* 1 */}
           <View style={styles.flexD}>
               <View style={styles.flexInfo}>
                   <Text >200</Text>
                   <Text >当日PC端PV量</Text>
              </View>
               <View style={styles.flexInfo}>
                   <Text>230</Text>
                   <Text>移动端PV量</Text>
               </View>
           </View>
           {/* 2*/}
           <View style={styles.flexD}>
              <View style={styles.flexInfo}>
                   <Text>1020</Text>
                   <Text>已完成订单总数</Text>
              </View>
               <View style={styles.flexInfo}>
                   <Text>2390</Text>
                   <Text>当日app下载量</Text>
               </View>
           </View>
           <Text>{'\n\n'}</Text>
           {/* 3 */}
           <View style={styles.flexD}>
               <TouchableOpacity style={styles.myImage}>
               <Image style={styles.ImageInfo} source={{uri:"http://meilele.applinzi.com/img/main/order.png"}}></Image>
               <Text>订单管理</Text>
               </TouchableOpacity>
               <TouchableOpacity>
               <Image  style={styles.ImageInfo} source={{uri:"http://meilele.applinzi.com/img/main/user.png"}}></Image>
               <Text>用户管理</Text>
               </TouchableOpacity>
           </View>
           <Text>{"\n"}</Text>
           {/* 4 */}
           <View style={styles.flexD}>
               <TouchableOpacity onPress={this.jump} style={styles.myImage}>
               <Image  style={styles.ImageInfo} source={{uri:"http://meilele.applinzi.com/img/main/product.png"}}></Image>
               <Text>商品管理</Text>
               </TouchableOpacity>
               <TouchableOpacity>
               <Image   style={styles.ImageInfo} source={{uri:"http://meilele.applinzi.com/img/main/setting.png"}}></Image>
               <Text>设置</Text>
               </TouchableOpacity>
           </View>
       </View>
   }
}
const styles=StyleSheet.create({
    container:{
        flex:1,
        backgroundColor:"#0aa1ed",
    },
    flexD:{
        flexDirection:"row",
    },
    flexInfo:{
        flex:1,
        height:100,
        justifyContent:"center",alignItems:"center",
        borderColor:'#fff',
        borderBottomWidth:2,
        borderRightWidth:2,
    },
    myImage:{
      flex:1,
      height:100,
      justifyContent:"center",
      alignItems:"center",
    },
    ImageInfo:{
        width:80,
        height:80,
    }
})